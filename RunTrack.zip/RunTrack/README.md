# RunTrack v3 (native Android)
Fused GPS + Kalman smoothing, own accelerometer pedometer, run/walk/cycle/vehicle detection, auto lap/loop counting,
auto-pause, minute-by-minute speed chart, 2D/3D speed-coloured route, post-run dashboard with best efforts (PRs),
cadence & stride insights, Memories with photos and notes, weekly/monthly progress, personal records, compare two runs, GPX export.
Foreground service keeps tracking with the screen off.

Build: upload zip to GitHub as RunTrack.zip (replace the old one) -> Actions builds -> Releases v1.0 -> app-debug.apk.
APK uses a fixed signing key, so v3 installs over v2 (v2 key = v3 key). Only v1 needs uninstalling.
