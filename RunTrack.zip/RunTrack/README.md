# RunTrack (native Android)
GPS run tracker: distance, speed, pace, steps, cadence, live route, auto loop/lap counting, works with screen off (foreground service). Runs saved on-device; GPX export.

## Build without Android Studio (free)
1. Create a GitHub repo, upload all these files (keep the .github folder), commit to `main`.
2. Actions tab -> "Build APK" runs automatically -> download `RunTrack-apk` artifact.
3. For a permanent download link: tag a release (`git tag v1.0 && git push --tags`) -> APK appears under Releases.

## Build with Android Studio
Open this folder -> let Gradle sync -> Run, or Build > Build APK.

## First run
Allow Location (Precise), Physical activity, Notifications. Set battery to "Unrestricted" for RunTrack for the most reliable screen-off tracking.
