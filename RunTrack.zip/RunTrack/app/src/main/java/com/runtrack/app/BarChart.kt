package com.runtrack.app

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*

/** Generic bar chart: minute speeds, cadence, stride, weekly distance. Colour = intensity, or one accent colour. */
class BarChart(c: Context) : View(c) {
    private var vals: List<Double> = emptyList()
    private var labels: List<String>? = null
    private var uniform = false
    private var dec = 1
    private var emptyText = "No data yet"
    private val d = c.resources.displayMetrics.density
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val axis = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2A2E34.toInt(); strokeWidth = 1 * d }
    private val avgP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = 1.5f * d; pathEffect = DashPathEffect(floatArrayOf(8 * d, 6 * d), 0f) }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF9AA1AB.toInt(); textSize = 10 * d }

    companion object {
        /** km/h for each minute; the last (partial) minute is divided by the seconds actually elapsed in it. */
        fun speeds(mins: List<Double>, total: Double): List<Double> {
            val n = mins.size
            return List(n) { i ->
                val sec = if (i < n - 1) 60.0 else (total - 60.0 * (n - 1)).coerceIn(10.0, 60.0)
                mins[i] / sec * 3.6
            }
        }
    }

    fun set(mins: List<Double>, total: Double) =
        setValues(speeds(mins, total), null, false, 1, "Minute-by-minute speed appears after the first minute")

    fun setValues(v: List<Double>, l: List<String>? = null, uni: Boolean = false, decimals: Int = 1, empty: String = "No data yet") {
        vals = v; labels = l; uniform = uni; dec = decimals; emptyText = empty; invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val n = vals.size
        txt.textAlign = Paint.Align.CENTER
        if (n == 0) { cv.drawText(emptyText, w / 2, h / 2, txt); return }
        val left = 34 * d; val bottom = h - 18 * d; val top = 14 * d
        val hi = vals.max(); val mn = vals.min(); val mx = max(hi, 0.1) * 1.15
        val f = "%." + dec + "f"
        txt.textAlign = Paint.Align.RIGHT
        for (i in 0..2) {
            val y = bottom - (bottom - top) * i / 2f
            cv.drawLine(left, y, w, y, axis); cv.drawText(f.format(mx * i / 2), left - 4 * d, y + 4 * d, txt)
        }
        val slot = (w - left - 4 * d) / n; val bw = min(slot * 0.72f, 36 * d)
        for (i in 0 until n) {
            val t = if (hi > mn) ((vals[i] - mn) / (hi - mn)).coerceIn(0.0, 1.0) else 0.5
            bar.color = if (uniform) ACC else Color.HSVToColor(floatArrayOf((140 * (1 - t)).toFloat(), 0.8f, 0.95f))
            val x = left + slot * i + (slot - bw) / 2
            val y = (bottom - (bottom - top) * (vals[i] / mx)).toFloat()
            if (vals[i] > 0) cv.drawRoundRect(x, y, x + bw, bottom, 3 * d, 3 * d, bar)
            if (n <= 10 && vals[i] > 0) { txt.textAlign = Paint.Align.CENTER; cv.drawText(f.format(vals[i]), x + bw / 2, y - 3 * d, txt) }
        }
        val nz = vals.filter { it > 0 }
        if (!uniform && nz.size > 1) {
            val avg = nz.average(); val ay = (bottom - (bottom - top) * (avg / mx)).toFloat()
            cv.drawLine(left, ay, w, ay, avgP)
            txt.textAlign = Paint.Align.LEFT; cv.drawText("avg " + f.format(avg), left + 4 * d, ay - 4 * d, txt)
        }
        txt.textAlign = Paint.Align.CENTER
        val every = max(1, ceil(n / 6.0).toInt())
        for (i in 0 until n step every) {
            val lb = labels?.getOrNull(i) ?: ((i + 1).toString() + "'")
            cv.drawText(lb, left + slot * i + slot / 2, h - 3 * d, txt)
        }
    }
}
