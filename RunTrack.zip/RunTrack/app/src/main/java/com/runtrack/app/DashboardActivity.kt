package com.runtrack.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs

class DashboardActivity : Activity() {
    private var id = 0L
    private lateinit var r: JSONObject
    private lateinit var note: EditText
    private lateinit var photoBox: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        id = intent.getLongExtra("id", 0L)
        val loaded = Store.get(this, id)
        if (loaded == null) { Toast.makeText(this, "Run not found", Toast.LENGTH_SHORT).show(); finish(); return }
        r = loaded
        build()
    }

    private fun big(label: String, value: String) = Stat(this, label, 30f).also { it.v.text = value }.view

    private fun pct(from: Double, to: Double) = if (from > 0) (to - from) / from * 100 else 0.0

    private fun build() {
        val dist = r.getDouble("dist"); val time = r.getDouble("time"); val steps = r.getInt("steps")
        val mdA = r.getJSONArray("modeDist"); val mtA = r.getJSONArray("modeTime")
        val md = DoubleArray(5) { mdA.getDouble(it) }; val mt = DoubleArray(5) { mtA.getDouble(it) }
        val minsA = r.getJSONArray("mins"); val mins = List(minsA.length()) { minsA.getDouble(it) }
        val stA = r.getJSONArray("minSteps"); val mSteps = List(stA.length()) { stA.getInt(it) }
        val ptsL = Tracker.ptsFromJson(r.getJSONArray("pts"))
        val avgKmh = if (time > 0) dist / time * 3.6 else 0.0
        val lapsA = r.getJSONArray("laps")
        val best = (0 until lapsA.length()).minOfOrNull { lapsA.getJSONObject(it).getDouble("t") }
        val kcal = r.getDouble("weight") * (md[M.RUN] * 1.0 + md[M.WALK] * 0.55 + md[M.CYCLE] * 0.28) / 1000
        val sp = BarChart.speeds(mins, time)
        val stride = r.getDouble("stride")

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        val df = java.text.SimpleDateFormat("EEEE, d MMM yyyy · HH:mm", java.util.Locale.getDefault())
        root.addView(tv("Run summary", 22f, WHITE, true))
        root.addView(tv(df.format(java.util.Date(r.getLong("date"))), 13f, MUTED).apply { setPadding(0, 0, 0, dp(8)) })
        root.addView(card(row(big("km", "%.2f".format(dist / 1000)), big("time", fmt(time)), big("min/km", paceStr(avgKmh)))))
        root.addView(card(statGrid(listOf(
            "avg km/h" to "%.1f".format(avgKmh),
            "max km/h" to "%.1f".format(r.getDouble("maxSpeed") * 3.6),
            "steps" to steps.toString(),
            "cadence spm" to (if (time > 0) (steps * 60 / time).toInt().toString() else "0"),
            "stride m" to (if (stride > 0) "%.2f".format(stride) else "--"),
            "kcal (est.)" to kcal.toInt().toString(),
            "climb m" to r.getDouble("elev").toInt().toString(),
            "laps" to lapsA.length().toString(),
            "best lap" to (if (best != null) fmt(best) else "--:--")))))

        val rv = RouteView(this).apply { pts = ptsL; layoutParams = LinearLayout.LayoutParams(-1, dp(300)) }
        val tg = btn("2D / 3D") { rv.is3d = !rv.is3d; rv.invalidate() }.apply { layoutParams = LinearLayout.LayoutParams(dp(100), dp(44)) }
        root.addView(card(row(tv("Route · colour = speed", 14f, WHITE, true).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }, tg), rv))

        // ---- minute by minute speed
        val ch = BarChart(this).apply { set(mins, time); layoutParams = LinearLayout.LayoutParams(-1, dp(190)) }
        val effort = if (sp.size >= 2) {
            val avg = sp.average()
            val hard = sp.count { it > avg * 1.1 }; val easy = sp.count { it < avg * 0.9 }
            val fast = sp.indices.maxByOrNull { sp[it] } ?: 0; val slow = sp.indices.minByOrNull { sp[it] } ?: 0
            "Effort: $hard min hard · ${sp.size - hard - easy} steady · $easy easy\n" +
                "Fastest minute #${fast + 1}: %.1f km/h   Slowest #${slow + 1}: %.1f km/h".format(sp[fast], sp[slow])
        } else "Run longer than a minute to see effort analysis."
        root.addView(card(tv("Effort · minute by minute (km/h)", 14f, WHITE, true), ch, tv(effort, 13f, MUTED)))

        // ---- cadence and stride insights
        val n = mins.size
        val cad = List(n) { i ->
            val sec = if (i < n - 1) 60.0 else (time - 60.0 * (n - 1)).coerceIn(10.0, 60.0)
            if (i < mSteps.size) mSteps[i] / sec * 60 else 0.0
        }
        val str = List(n) { i -> if (i < mSteps.size && mSteps[i] >= 15) mins[i] / mSteps[i] else 0.0 }
        val chC = BarChart(this).apply { setValues(cad, null, false, 0, "Cadence appears after the first minute"); layoutParams = LinearLayout.LayoutParams(-1, dp(130)) }
        val chS = BarChart(this).apply { setValues(str, null, false, 2, "Stride appears after the first minute"); layoutParams = LinearLayout.LayoutParams(-1, dp(130)) }
        root.addView(card(tv("Cadence & stride", 14f, WHITE, true),
            tv("Cadence (steps per minute)", 12f, MUTED), chC, tv("Stride length (m per step)", 12f, MUTED), chS,
            tv(formInsight(cad, str), 13f, WHITE).apply { setPadding(0, dp(6), 0, 0) }))

        // ---- travel modes
        val modeViews = ArrayList<View>()
        modeViews.add(tv("Travel modes detected", 14f, WHITE, true))
        for (m in 1..4) if (md[m] > 5 || mt[m] > 5)
            modeViews.add(row(cell(M.names[m], 1f, WHITE, true), cell("%.2f km".format(md[m] / 1000), 1f), cell(fmt(mt[m]), 1f),
                cell("%.1f km/h".format(if (mt[m] > 0) md[m] / mt[m] * 3.6 else 0.0), 1.2f, MUTED)))
        modeViews.add(tv("Headline distance counts on-foot movement (or the activity you forced). Other modes are listed here only.", 11f, MUTED))
        root.addView(card(*modeViews.toTypedArray()))

        if (lapsA.length() > 0) {
            val lv = ArrayList<View>(); lv.add(tv("Laps", 14f, WHITE, true))
            for (i in 0 until lapsA.length()) {
                val l = lapsA.getJSONObject(i); val isBest = best != null && l.getDouble("t") == best
                lv.add(row(cell("Lap " + l.getInt("n"), 1f, if (isBest) GREEN else WHITE, isBest), cell(l.getDouble("d").toInt().toString() + " m"),
                    cell(fmt(l.getDouble("t")), 1f, if (isBest) GREEN else WHITE, isBest)))
            }
            root.addView(card(*lv.toTypedArray()))
        }

        // ---- photos + note
        photoBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        note = EditText(this).apply {
            hint = "Write a note about this run…"; setHintTextColor(MUTED); setTextColor(WHITE)
            setText(r.optString("note", "")); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 2; gravity = Gravity.TOP
        }
        root.addView(card(tv("Memory", 14f, WHITE, true),
            HorizontalScrollView(this).apply { addView(photoBox) },
            btn("Add photo") { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 1) }
                .apply { layoutParams = LinearLayout.LayoutParams(-1, dp(48)) }, note))
        renderPhotos()

        root.addView(row(
            btn("Share GPX") {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_SUBJECT, "run.gpx").putExtra(Intent.EXTRA_TEXT, Tracker.gpx(r)), "Export GPX"))
            },
            btn("Delete") {
                AlertDialog.Builder(this).setTitle("Delete this run?").setPositiveButton("Delete") { _, _ ->
                    val ph = r.getJSONArray("photos"); for (i in 0 until ph.length()) File(ph.getString(i)).delete()
                    Store.del(this, id); finish()
                }.setNegativeButton("Cancel", null).show()
            }))
        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(root) })
    }

    /** Compares the first third of the run with the last third to spot fatigue or a strong finish. */
    private fun formInsight(cad: List<Double>, str: List<Double>): String {
        val n = cad.size
        if (n < 6) return "Run at least 6 minutes to get a form and fatigue analysis."
        val k = n / 3
        fun avg(l: List<Double>, from: Int, to: Int): Double { val x = l.subList(from, to).filter { it > 0 }; return if (x.isEmpty()) 0.0 else x.average() }
        val c1 = avg(cad, 0, k); val c2 = avg(cad, n - k, n); val s1 = avg(str, 0, k); val s2 = avg(str, n - k, n)
        if (c1 <= 0 || s1 <= 0 || c2 <= 0 || s2 <= 0) return "Not enough steady running steps to analyse your form."
        val dc = pct(c1, c2); val ds = pct(s1, s2)
        val verdict = when {
            ds < -5 -> "Your stride got shorter late in the run, a common sign of fatigue. Pacing the early part more evenly and leg-strength work usually help."
            ds > 5 -> "You finished with a longer stride. Strong finish!"
            abs(dc) < 3 -> "Very steady form from start to finish."
            else -> "Your rhythm changed a little but your stride held up."
        }
        return "Cadence: first third %.0f → last third %.0f spm (%+.0f%%)\nStride: first third %.2f → last third %.2f m (%+.0f%%)\n%s"
            .format(c1, c2, dc, s1, s2, ds, verdict)
    }

    private fun renderPhotos() {
        photoBox.removeAllViews()
        val ph = r.getJSONArray("photos")
        for (i in 0 until ph.length()) {
            val path = ph.getString(i)
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                layoutParams = LinearLayout.LayoutParams(dp(120), dp(120)).apply { rightMargin = dp(8) }
                setImageBitmap(thumb(path, 300))
                setOnClickListener { showPhoto(i, path) }
            }
            photoBox.addView(iv)
        }
    }

    private fun showPhoto(i: Int, path: String) {
        val iv = ImageView(this).apply { adjustViewBounds = true; setImageBitmap(thumb(path, 1100)) }
        AlertDialog.Builder(this).setView(iv).setPositiveButton("Close", null)
            .setNegativeButton("Remove") { _, _ ->
                File(path).delete(); r.getJSONArray("photos").remove(i); Store.put(this, r); renderPhotos()
            }.show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1 && res == RESULT_OK) data?.data?.let { addPhoto(it) }
    }

    private fun addPhoto(uri: Uri) {
        try {
            val dir = File(filesDir, "photos").apply { mkdirs() }
            val f = File(dir, id.toString() + "_" + System.currentTimeMillis() + ".jpg")
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1; while (o.outWidth / s > 1600) s *= 2
            var bm: Bitmap = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
            } ?: return
            val rot = contentResolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
            } ?: 0f
            if (rot != 0f) bm = Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, Matrix().apply { postRotate(rot) }, true)
            FileOutputStream(f).use { bm.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            r.getJSONArray("photos").put(f.absolutePath); Store.put(this, r); renderPhotos()
        } catch (e: Exception) { Toast.makeText(this, "Could not add photo", Toast.LENGTH_SHORT).show() }
    }

    override fun onPause() {
        super.onPause()
        try { if (::note.isInitialized) { r.put("note", note.text.toString()); Store.put(this, r) } } catch (e: Exception) {}
    }
}
