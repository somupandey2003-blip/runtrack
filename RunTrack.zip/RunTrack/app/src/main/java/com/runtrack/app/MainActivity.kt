package com.runtrack.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.*
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var route: RouteView
    private lateinit var gps: TextView
    private lateinit var lapsTv: TextView
    private lateinit var mode: Spinner
    private lateinit var lapLen: EditText
    private lateinit var bStart: Button
    private lateinit var bPause: Button
    private lateinit var bStop: Button
    private lateinit var bLap: Button
    private val tvs = HashMap<String, TextView>()
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 1000) } }

    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
    }
    private fun stat(label: String): LinearLayout {
        val v = TextView(this).apply { text = "0"; textSize = 28f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD }
        val l = TextView(this).apply { text = label.uppercase(); textSize = 11f; setTextColor(0xFF9AA1AB.toInt()) }
        tvs[label] = v
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f); addView(v); addView(l)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        gps = TextView(this).apply { setTextColor(0xFF9AA1AB.toInt()); text = "GPS idle" }
        route = RouteView(this)
        root.addView(gps)
        root.addView(route, LinearLayout.LayoutParams(-1, dp(240)))
        listOf(listOf("km", "time"), listOf("km/h", "min/km"), listOf("steps", "loops"),
            listOf("lap m", "lap time"), listOf("best lap", "cadence")).forEach { pair ->
            root.addView(row().apply { pair.forEach { addView(stat(it)) } })
        }
        mode = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Auto-lap: return to start", "Auto-lap: every N metres"))
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        lapLen = EditText(this).apply {
            setText("400"); inputType = InputType.TYPE_CLASS_NUMBER; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(90), -2)
        }
        root.addView(row().apply { addView(mode); addView(lapLen) })
        bStart = btn("Start") { start() }
        bPause = btn("Pause") { send("PAUSE") }
        bStop = btn("Finish") { send("STOP") }
        bLap = btn("Lap") { send("LAP") }
        root.addView(row().apply { addView(bStart); addView(bPause); addView(bStop); addView(bLap) })
        root.addView(btn("History / export GPX") { history() }.apply { layoutParams = LinearLayout.LayoutParams(-1, -2) })
        lapsTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(0, dp(8), 0, 0) }
        root.addView(lapsTv)
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF0E1013.toInt()); isFillViewport = true; addView(root) })
    }

    override fun onResume() { super.onResume(); Tracker.onChange = { runOnUiThread { refresh() } }; h.post(tick) }
    override fun onPause() { super.onPause(); Tracker.onChange = null; h.removeCallbacks(tick) }

    private fun send(a: String) = startService(Intent(this, TrackingService::class.java).setAction(a))

    private fun start() {
        val need = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACTIVITY_RECOGNITION, Manifest.permission.POST_NOTIFICATIONS)
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(need, 1); return
        }
        Tracker.lapMode = mode.selectedItemPosition
        Tracker.lapLen = lapLen.text.toString().toDoubleOrNull() ?: 400.0
        startForegroundService(Intent(this, TrackingService::class.java).setAction("START"))
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) start()
        else Toast.makeText(this, "Location permission is required", Toast.LENGTH_LONG).show()
    }

    private fun set(k: String, v: String) { tvs[k]?.text = v }

    private fun refresh() {
        val t = Tracker; val el = t.elapsed()
        val kmh = if (t.running) t.speed * 3.6 else 0.0
        set("km", "%.2f".format(t.dist / 1000)); set("time", fmt(el))
        set("km/h", "%.1f".format(kmh)); set("min/km", if (kmh > 1) fmt(3600 / kmh) else "--:--")
        set("steps", t.stepsShown().toString()); set("loops", t.laps.size.toString())
        set("lap m", Math.round(t.dist - t.lapD0).toString()); set("lap time", fmt(el - t.lapT0))
        set("best lap", if (t.laps.isEmpty()) "--:--" else fmt(t.laps.minOf { it.t }))
        set("cadence", if (el > 20 && t.running) (t.stepsShown() * 60 / el).toInt().toString() else "0")
        gps.text = if (!t.active) "GPS idle" else
            (if (t.acc <= 10) "GPS strong" else if (t.acc <= 25) "GPS ok" else "GPS weak") + "  ±" + t.acc.toInt() + " m"
        route.pts = ArrayList(t.pts); route.invalidate()
        lapsTv.text = t.laps.reversed().joinToString("\n") { "Lap %d   %d m   %s".format(it.n, it.d.toInt(), fmt(it.t)) }
        bStart.isEnabled = !t.active; bPause.isEnabled = t.active; bStop.isEnabled = t.active; bLap.isEnabled = t.active
        bPause.text = if (t.active && !t.running) "Resume" else "Pause"
    }

    private fun history() {
        val all = Tracker.load(this)
        if (all.length() == 0) { Toast.makeText(this, "No runs yet", Toast.LENGTH_SHORT).show(); return }
        val f = java.text.SimpleDateFormat("d MMM HH:mm", java.util.Locale.getDefault())
        val items = Array(all.length()) { i ->
            val r = all.getJSONObject(i)
            "%s  ·  %.2f km  ·  %s  ·  %d laps".format(f.format(java.util.Date(r.getLong("date"))),
                r.getDouble("dist") / 1000, fmt(r.getDouble("time")), r.getJSONArray("laps").length())
        }
        AlertDialog.Builder(this).setTitle("Tap a run to export GPX").setItems(items) { _, i ->
            val r: JSONObject = all.getJSONObject(i)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_SUBJECT, "run.gpx").putExtra(Intent.EXTRA_TEXT, Tracker.gpx(r)), "Export GPX"))
        }.show()
    }
}
