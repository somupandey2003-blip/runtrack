package com.runtrack.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*

class MainActivity : Activity() {
    private lateinit var route: RouteView
    private lateinit var chart: BarChart
    private lateinit var gps: TextView
    private lateinit var lapsTv: TextView
    private lateinit var lapsCard: LinearLayout
    private lateinit var lapSp: Spinner
    private lateinit var actSp: Spinner
    private lateinit var lapLen: EditText
    private lateinit var weightEt: EditText
    private lateinit var autoCb: CheckBox
    private lateinit var bStart: Button
    private lateinit var bPause: Button
    private lateinit var bStop: Button
    private lateinit var bLap: Button
    private lateinit var bReset: Button
    private val st = HashMap<String, Stat>()
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 1000) } }
    private val cfg by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    private fun stat(label: String, size: Float = 20f) = Stat(this, label, size).also { st[label] = it }.view
    private fun open(c: Class<*>) = startActivity(Intent(this, c))
    private fun spin(items: List<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
    }
    private fun num(v: String, w: Int) = EditText(this).apply {
        setText(v); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setTextColor(Color.WHITE); gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(w), -2)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Tracker.recover(this)
        Tracker.autoPause = cfg.getBoolean("ap", true)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(8)) }
        root.addView(tv("RunTrack", 24f, WHITE, true))
        gps = tv("Ready · tap Start", 12f, MUTED).apply { setPadding(0, 0, 0, dp(6)) }
        root.addView(gps)
        root.addView(row(
            btn("Memories") { open(MemoriesActivity::class.java) }.apply { textSize = 13f },
            btn("Progress") { open(ProgressActivity::class.java) }.apply { textSize = 13f }))
        root.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(8)) })

        root.addView(card(row(stat("km", 34f), stat("time", 34f), stat("min/km", 34f))))
        root.addView(card(row(stat("km/h"), stat("steps"), stat("cadence")), row(stat("loops"), stat("lap m"), stat("lap time"))))

        route = RouteView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(250)) }
        val b3d = btn("2D / 3D") { route.is3d = !route.is3d; route.invalidate() }.apply { layoutParams = LinearLayout.LayoutParams(dp(100), dp(44)) }
        root.addView(card(row(tv("Route · colour = speed", 14f, WHITE, true).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }, b3d), route))

        chart = BarChart(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(140)) }
        root.addView(card(tv("Minute-by-minute speed (km/h)", 14f, WHITE, true), chart))

        lapsTv = tv("", 14f)
        lapsCard = card(tv("Laps", 14f, WHITE, true), lapsTv).apply { visibility = View.GONE }
        root.addView(lapsCard)

        // ---- settings (remembered between launches)
        actSp = spin(listOf("Activity: Auto-detect", "Run", "Walk", "Cycle", "Vehicle"))
        actSp.setSelection(if (Tracker.active) Tracker.manual else cfg.getInt("act", 0))
        actSp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                Tracker.manual = pos; cfg.edit().putInt("act", pos).apply()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        weightEt = num(cfg.getString("w", "70") ?: "70", 70)
        lapSp = spin(listOf("Auto-lap: return to start", "Auto-lap: every N metres", "Learn loop: 1st lap sets length"))
        lapSp.setSelection(cfg.getInt("lapMode", 0))
        lapLen = num(cfg.getString("lapLen", "400") ?: "400", 80)
        autoCb = CheckBox(this).apply {
            text = "Auto-pause when I stop"; setTextColor(WHITE); isChecked = cfg.getBoolean("ap", true)
            setOnCheckedChangeListener { _, on -> Tracker.autoPause = on; cfg.edit().putBoolean("ap", on).apply() }
        }
        root.addView(card(tv("Run settings", 14f, WHITE, true),
            row(actSp, tv("  weight kg ", 13f, MUTED), weightEt),
            row(lapSp, tv("  lap m ", 13f, MUTED), lapLen),
            autoCb,
            tv("Auto-detect labels run, walk, cycle or vehicle from speed and step rhythm. Force a mode if it guesses wrong.", 11f, MUTED)))

        // ---- control bar, always visible
        bStart = pbtn("Start") { start() }
        bPause = btn("Pause") { send("PAUSE") }
        bStop = btn("Finish") { confirmFinish() }
        bLap = btn("Lap") { send("LAP") }
        bReset = btn("Reset") { resetRun() }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(CARD); setPadding(dp(8), dp(6), dp(8), dp(6))
            addView(row(bStart, bPause, bStop)); addView(row(bLap, bReset))
        }
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(BG)
            addView(ScrollView(this@MainActivity).apply { addView(root) }, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(bar, LinearLayout.LayoutParams(-1, -2))
        }
        setContentView(outer)
    }

    override fun onResume() { super.onResume(); Tracker.onChange = { runOnUiThread { refresh() } }; h.post(tick) }
    override fun onPause() { super.onPause(); Tracker.onChange = null; h.removeCallbacks(tick) }

    private fun send(a: String) = startService(Intent(this, TrackingService::class.java).setAction(a))

    private fun start() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACTIVITY_RECOGNITION, Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        Tracker.lapMode = lapSp.selectedItemPosition
        Tracker.lapLen = (lapLen.text.toString().toDoubleOrNull() ?: 400.0).coerceAtLeast(50.0)
        Tracker.manual = actSp.selectedItemPosition
        Tracker.autoPause = autoCb.isChecked
        Tracker.weight = (weightEt.text.toString().toDoubleOrNull() ?: 70.0).coerceIn(20.0, 300.0)
        cfg.edit().putString("w", weightEt.text.toString()).putInt("lapMode", Tracker.lapMode)
            .putString("lapLen", lapLen.text.toString()).apply()
        startForegroundService(Intent(this, TrackingService::class.java).setAction("START"))
        if (!cfg.getBoolean("batt", false)) {
            cfg.edit().putBoolean("batt", true).apply()
            try {
                if (!(getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName))
                    startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + packageName)))
            } catch (e: Exception) {}
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) start()
        else Toast.makeText(this, "Location permission is required to track your run", Toast.LENGTH_LONG).show()
    }

    private fun confirmFinish() {
        AlertDialog.Builder(this).setTitle("Finish run?")
            .setMessage("Your run is saved to Memories and the summary opens.")
            .setPositiveButton("Finish") { _, _ -> finishRun() }
            .setNegativeButton("Keep going", null).show()
    }

    private fun finishRun() {
        val id = Tracker.finishRun(this)
        send("STOP")
        if (id != null) startActivity(Intent(this, DashboardActivity::class.java).putExtra("id", id))
        else Toast.makeText(this, "Run too short to save (under 20 m)", Toast.LENGTH_SHORT).show()
        refresh()
    }

    private fun resetRun() {
        AlertDialog.Builder(this).setTitle("Reset run?")
            .setMessage("The current run is saved to Memories (if longer than 20 m) and a fresh run starts at zero. Tracking keeps going.")
            .setPositiveButton("Reset") { _, _ ->
                val saved = Tracker.resetRun(this)
                Toast.makeText(this, if (saved) "Saved to Memories. Fresh run started" else "Fresh run started", Toast.LENGTH_SHORT).show()
                refresh()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun set(k: String, v: String) { st[k]?.v?.text = v }

    private fun refresh() {
        val t = Tracker; val el = t.elapsed()
        val kmh = if (t.running) t.speed * 3.6 else 0.0
        set("km", "%.2f".format(t.dist / 1000)); set("time", fmt(el))
        set("km/h", "%.1f".format(kmh)); set("min/km", paceStr(kmh))
        set("steps", t.stepsShown().toString()); set("cadence", if (t.running) t.cadence().toString() else "0")
        set("loops", t.laps.size.toString())
        set("lap m", Math.round(t.dist - t.lapD0).toString()); set("lap time", fmt(el - t.lapT0))
        val q = if (t.acc <= 10) "GPS strong" else if (t.acc <= 25) "GPS ok" else "GPS weak"
        gps.text = when {
            !t.active -> "Ready · tap Start (wait for a strong GPS signal outdoors)"
            t.autoPaused -> "Auto-paused · start moving to resume"
            !t.running -> "Paused"
            else -> M.names[t.mode] + (if (t.manual > 0) " (manual)" else " (auto)") + " · " + q + " ±" + t.acc.toInt() + " m"
        }
        route.pts = ArrayList(t.pts); route.invalidate()
        chart.set(ArrayList(t.mins), el)
        lapsCard.visibility = if (t.laps.isEmpty()) View.GONE else View.VISIBLE
        if (t.laps.isNotEmpty()) {
            val bestLap = t.laps.minOf { it.t }
            lapsTv.text = (if (t.lapMode == 2 && t.loopLen > 0) "Loop length locked: %d m\n".format(t.loopLen.toInt()) else "") +
                "Best lap " + fmt(bestLap) + "\n" +
                t.laps.reversed().joinToString("\n") { "Lap %d   %d m   %s".format(it.n, it.d.toInt(), fmt(it.t)) }
        }
        bStart.enable(!t.active); bPause.enable(t.active); bStop.enable(t.active)
        bLap.enable(t.active && t.running); bReset.enable(t.active)
        bPause.text = if (t.active && !t.running) "Resume" else "Pause"
    }
}
