package com.runtrack.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MemoriesActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var head: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        root.addView(tv("Memories", 24f, WHITE, true))
        head = tv("", 13f, MUTED).apply { setPadding(0, 0, 0, dp(8)) }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(head)
        root.addView(row(
            btn("Progress") { startActivity(Intent(this, ProgressActivity::class.java)) }))
        root.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(8)) })
        root.addView(list)
        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(root) })
    }

    override fun onResume() { super.onResume(); fill() }

    private fun fill() {
        list.removeAllViews()
        val df = java.text.SimpleDateFormat("EEE d MMM yyyy · HH:mm", java.util.Locale.getDefault())
        var total = 0.0; var count = 0
        for (id in Store.ids(this)) {
            val r = try { Store.get(this, id) } catch (e: Exception) { null } ?: continue
            val dist = r.getDouble("dist"); val time = r.getDouble("time")
            total += dist; count++
            val ph = r.getJSONArray("photos")
            val pic: View = if (ph.length() > 0)
                ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setImageBitmap(thumb(ph.getString(0), 200)) }
            else tv("🏃", 28f).apply { gravity = Gravity.CENTER; setBackgroundColor(BG) }
            pic.layoutParams = LinearLayout.LayoutParams(dp(72), dp(72)).apply { rightMargin = dp(12) }
            val kmh = if (time > 0) dist / time * 3.6 else 0.0
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                addView(tv("%.2f km · %s".format(dist / 1000, fmt(time)), 17f, WHITE, true))
                addView(tv(df.format(java.util.Date(r.getLong("date"))), 12f, MUTED))
                addView(tv("%s /km · %d steps · %d laps · %d photos".format(paceStr(kmh), r.getInt("steps"),
                    r.getJSONArray("laps").length(), ph.length()), 12f, MUTED))
            }
            val c = card(row(pic, info))
            c.setOnClickListener { startActivity(Intent(this, DashboardActivity::class.java).putExtra("id", id)) }
            list.addView(c)
        }
        head.text = if (count == 0) "No runs yet. Finish a run and it appears here." else "%d runs · %.1f km total".format(count, total / 1000)
    }
}
