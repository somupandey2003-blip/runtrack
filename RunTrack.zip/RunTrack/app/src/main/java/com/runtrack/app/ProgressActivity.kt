package com.runtrack.app

import android.app.Activity
import android.os.Bundle
import android.widget.*
import java.util.Calendar

class ProgressActivity : Activity() {
    private lateinit var body: LinearLayout
    private lateinit var bW: Button
    private lateinit var bM: Button
    private var weeks = true

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        root.addView(tv("Progress", 24f, WHITE, true))
        bW = btn("Weeks") { weeks = true; build() }
        bM = btn("Months") { weeks = false; build() }
        root.addView(row(bW, bM))
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, 0) }
        root.addView(body)
        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(root) })
        build()
    }

    private fun build() {
        body.removeAllViews()
        bW.alpha = if (weeks) 1f else 0.5f; bM.alpha = if (weeks) 0.5f else 1f
        val runs = Stats.sums(this)
        if (runs.isEmpty()) {
            body.addView(card(tv("No runs yet. Finish a run and your progress shows up here.", 14f, MUTED))); return
        }
        val n = if (weeks) 8 else 6
        val now = System.currentTimeMillis()
        val first = if (weeks) Stats.weekStart(now) else Stats.monthStart(now)
        val starts = ArrayList<Long>()
        for (k in n - 1 downTo 0) {
            val c = Calendar.getInstance(); c.timeInMillis = first
            if (weeks) c.add(Calendar.DAY_OF_YEAR, -7 * k) else c.add(Calendar.MONTH, -k)
            starts.add(c.timeInMillis)
        }
        val km = DoubleArray(n); val sec = DoubleArray(n); val cnt = IntArray(n)
        for (r in runs) {
            val idx = starts.indexOfLast { it <= r.date }
            if (idx >= 0) { km[idx] += r.dist / 1000; sec[idx] += r.time; cnt[idx]++ }
        }
        val lf = java.text.SimpleDateFormat(if (weeks) "d MMM" else "MMM", java.util.Locale.getDefault())
        val labels = starts.map { lf.format(java.util.Date(it)) }
        val cur = n - 1; val prev = n - 2
        val unit = if (weeks) "week" else "month"
        val pace = if (km[cur] > 0.05) fmt(sec[cur] / km[cur]) + " /km" else "--"
        val diff = km[cur] - km[prev]
        val delta = when {
            km[prev] <= 0 && km[cur] <= 0 -> "No runs this $unit yet. Time to lace up!"
            km[prev] <= 0 -> "Nothing last $unit, so every kilometre is progress."
            Math.abs(diff) < 0.05 -> "Same distance as last $unit."
            diff > 0 -> "▲ %.1f km more than last %s".format(diff, unit)
            else -> "▼ %.1f km less than last %s".format(-diff, unit)
        }
        body.addView(card(tv("This $unit", 14f, MUTED),
            statGrid(listOf("runs" to cnt[cur].toString(), "km" to "%.1f".format(km[cur]),
                "time" to fmt(sec[cur]), "avg pace" to pace), 2),
            tv(delta, 13f, if (diff >= 0 && km[cur] > 0) GREEN else MUTED)))

        val ch = BarChart(this).apply { setValues(km.toList(), labels, true, 1, ""); layoutParams = LinearLayout.LayoutParams(-1, dp(170)) }
        body.addView(card(tv("Distance per $unit (km)", 14f, WHITE, true), ch))

        val bestIdx = km.indices.maxByOrNull { km[it] } ?: 0
        val totalKm = runs.sumOf { it.dist } / 1000; val totalT = runs.sumOf { it.time }
        val streak = Stats.streak(runs)
        body.addView(card(tv("All time", 14f, WHITE, true),
            statGrid(listOf("runs" to runs.size.toString(), "km" to "%.1f".format(totalKm),
                "time" to fmt(totalT), "steps" to runs.sumOf { it.steps }.toString(),
                "day streak" to streak.toString(), "climb m" to runs.sumOf { it.climb }.toInt().toString())),
            tv(if (km[bestIdx] > 0) "Best $unit shown: " + labels[bestIdx] + " with %.1f km".format(km[bestIdx]) else "", 12f, MUTED)))
    }
}
