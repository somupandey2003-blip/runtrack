package com.runtrack.app

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*

/** Draws the live route (no map tiles, so no API key and fully offline). */
class RouteView(c: Context) : View(c) {
    var pts: List<Tracker.Pt> = emptyList()
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFC4C02.toInt(); strokeWidth = 8f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grid = Paint().apply { color = 0xFF2A2E34.toInt(); strokeWidth = 2f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF9AA1AB.toInt(); textSize = 36f; textAlign = Paint.Align.CENTER }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(0xFF1A1D21.toInt())
        var x = 0f; while (x < w) { c.drawLine(x, 0f, x, h, grid); x += 100f }
        var y = 0f; while (y < h) { c.drawLine(0f, y, w, y, grid); y += 100f }
        if (pts.isEmpty()) { c.drawText("Route appears here", w / 2, h / 2, txt); return }
        val R = 6371000.0; val la0 = pts[0].lat; val k = cos(Math.toRadians(la0))
        val xs = pts.map { Math.toRadians(it.lon - pts[0].lon) * R * k }
        val ys = pts.map { -Math.toRadians(it.lat - la0) * R }
        val span = max(max(xs.max() - xs.min(), ys.max() - ys.min()), 60.0)
        val sc = (min(w, h) - 80f) / span
        val ox = w / 2 - (xs.max() + xs.min()) / 2 * sc; val oy = h / 2 - (ys.max() + ys.min()) / 2 * sc
        val p = Path()
        for (i in xs.indices) { val X = (xs[i] * sc + ox).toFloat(); val Y = (ys[i] * sc + oy).toFloat(); if (i == 0) p.moveTo(X, Y) else p.lineTo(X, Y) }
        c.drawPath(p, line)
        dot.color = 0xFF22C55E.toInt(); c.drawCircle((xs[0] * sc + ox).toFloat(), (ys[0] * sc + oy).toFloat(), 14f, dot)
        dot.color = 0xFF3B82F6.toInt(); c.drawCircle((xs.last() * sc + ox).toFloat(), (ys.last() * sc + oy).toFloat(), 14f, dot)
    }
}
