package com.runtrack.app

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/** Route drawn offline (no map tiles). Colour = speed. 2D top view, or draggable 3D view using altitude. */
class RouteView(c: Context) : View(c) {
    var pts: List<Tracker.Pt> = emptyList()
    var is3d = false
    private var yaw = -0.6
    private var pitch = 52.0
    private var lx = 0f; private var ly = 0f
    private val d = c.resources.displayMetrics.density
    private val seg = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 5 * d; strokeCap = Paint.Cap.ROUND }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 11 * d; strokeCap = Paint.Cap.ROUND; color = 0x33FFFFFF }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 3 * d; color = 0x66000000; strokeCap = Paint.Cap.ROUND }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 2 * d }
    private val grid = Paint().apply { color = 0xFF2A2E34.toInt(); strokeWidth = 1 * d }
    private val ground = Paint().apply { color = 0xFF22262B.toInt() }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF9AA1AB.toInt(); textSize = 11 * d; textAlign = Paint.Align.CENTER }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!is3d) return false
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y; parent?.requestDisallowInterceptTouchEvent(true) }
            MotionEvent.ACTION_MOVE -> {
                yaw += (e.x - lx) * 0.01; pitch = (pitch + (e.y - ly) * 0.2).coerceIn(15.0, 85.0)
                lx = e.x; ly = e.y; invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> parent?.requestDisallowInterceptTouchEvent(false)
        }
        return true
    }

    private fun col(s: Double, lo: Double, hi: Double): Int {
        val t = if (hi > lo) ((s - lo) / (hi - lo)).coerceIn(0.0, 1.0) else 0.5
        return Color.HSVToColor(floatArrayOf((140 * (1 - t)).toFloat(), 0.85f, 0.95f))
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        cv.drawColor(0xFF1A1D21.toInt())
        val n = pts.size
        if (n < 2) {
            var x = 0f; while (x < w) { cv.drawLine(x, 0f, x, h, grid); x += 40 * d }
            var y = 0f; while (y < h) { cv.drawLine(0f, y, w, y, grid); y += 40 * d }
            cv.drawText("Route appears here once you start moving", w / 2, h / 2, txt); return
        }
        val R = 6371000.0; val la0 = pts[0].lat; val lo0 = pts[0].lon; val k = cos(Math.toRadians(la0))
        val X = DoubleArray(n) { Math.toRadians(pts[it].lon - lo0) * R * k }
        val Y = DoubleArray(n) { Math.toRadians(pts[it].lat - la0) * R }
        val a0 = pts[0].alt
        val Z = DoubleArray(n) { pts[it].alt - a0 }
        val xmin = X.min(); val xmax = X.max(); val ymin = Y.min(); val ymax = Y.max()
        val span = max(max(xmax - xmin, ymax - ymin), 60.0)
        val zr = Z.max() - Z.min()
        val zs = if (is3d && zr > 1) min(20.0, 0.25 * span / zr) else 1.0     // exaggerate height so it is visible
        val pr = Math.toRadians(pitch); val cy = cos(yaw); val sy = sin(yaw)
        fun proj(x: Double, y: Double, z: Double): DoubleArray =
            if (is3d) { val xr = x * cy - y * sy; val yr = x * sy + y * cy; doubleArrayOf(xr, -(yr * sin(pr) + z * zs * cos(pr))) }
            else doubleArrayOf(x, -y)
        val P = Array(n) { proj(X[it], Y[it], Z[it]) }
        val m = span * 0.08
        val gx0 = xmin - m; val gx1 = xmax + m; val gy0 = ymin - m; val gy1 = ymax + m
        var bx0 = 1e18; var bx1 = -1e18; var by0 = 1e18; var by1 = -1e18
        for (p in P) { bx0 = min(bx0, p[0]); bx1 = max(bx1, p[0]); by0 = min(by0, p[1]); by1 = max(by1, p[1]) }
        if (is3d) for (p in listOf(proj(gx0, gy0, 0.0), proj(gx1, gy0, 0.0), proj(gx1, gy1, 0.0), proj(gx0, gy1, 0.0))) {
            bx0 = min(bx0, p[0]); bx1 = max(bx1, p[0]); by0 = min(by0, p[1]); by1 = max(by1, p[1])
        }
        val sc = min((w - 40 * d) / max(bx1 - bx0, 1.0), (h - 40 * d) / max(by1 - by0, 1.0))
        val ox = w / 2 - (bx0 + bx1) / 2 * sc; val oy = h / 2 - (by0 + by1) / 2 * sc
        fun sx(p: DoubleArray) = (p[0] * sc + ox).toFloat()
        fun sY(p: DoubleArray) = (p[1] * sc + oy).toFloat()

        if (is3d) {
            val c0 = proj(gx0, gy0, 0.0); val c1 = proj(gx1, gy0, 0.0); val c2 = proj(gx1, gy1, 0.0); val c3 = proj(gx0, gy1, 0.0)
            val path = Path().apply { moveTo(sx(c0), sY(c0)); lineTo(sx(c1), sY(c1)); lineTo(sx(c2), sY(c2)); lineTo(sx(c3), sY(c3)); close() }
            cv.drawPath(path, ground)
            for (i in 0..6) {
                val t = i / 6.0
                val a = proj(gx0 + t * (gx1 - gx0), gy0, 0.0); val b = proj(gx0 + t * (gx1 - gx0), gy1, 0.0)
                cv.drawLine(sx(a), sY(a), sx(b), sY(b), grid)
                val e = proj(gx0, gy0 + t * (gy1 - gy0), 0.0); val f = proj(gx1, gy0 + t * (gy1 - gy0), 0.0)
                cv.drawLine(sx(e), sY(e), sx(f), sY(f), grid)
            }
            for (i in 1 until n) { val a = proj(X[i - 1], Y[i - 1], 0.0); val b = proj(X[i], Y[i], 0.0); cv.drawLine(sx(a), sY(a), sx(b), sY(b), shadow) }
        } else {
            var x = 0f; while (x < w) { cv.drawLine(x, 0f, x, h, grid); x += 40 * d }
            var y = 0f; while (y < h) { cv.drawLine(0f, y, w, y, grid); y += 40 * d }
            for (i in 1 until n) cv.drawLine(sx(P[i - 1]), sY(P[i - 1]), sx(P[i]), sY(P[i]), glow)
        }
        val lo = pts.minOf { it.spd }; val hi = pts.maxOf { it.spd }
        for (i in 1 until n) { seg.color = col(pts[i].spd, lo, hi); cv.drawLine(sx(P[i - 1]), sY(P[i - 1]), sx(P[i]), sY(P[i]), seg) }
        dot.color = 0xFF22C55E.toInt(); cv.drawCircle(sx(P[0]), sY(P[0]), 7 * d, dot); cv.drawCircle(sx(P[0]), sY(P[0]), 7 * d, ring)
        dot.color = 0xFF3B82F6.toInt(); cv.drawCircle(sx(P[n - 1]), sY(P[n - 1]), 7 * d, dot); cv.drawCircle(sx(P[n - 1]), sY(P[n - 1]), 7 * d, ring)

        // legend: slow -> fast
        val lx0 = w - 100 * d; val ly0 = h - 14 * d
        for (j in 0 until 40) { dot.color = col(lo + (hi - lo) * j / 39.0, lo, hi); cv.drawRect(lx0 + j * 2 * d, ly0, lx0 + (j + 1) * 2 * d, ly0 + 5 * d, dot) }
        txt.textAlign = Paint.Align.LEFT; cv.drawText("slow", lx0 - 30 * d, ly0 + 6 * d, txt)
        txt.textAlign = Paint.Align.RIGHT; cv.drawText("fast", lx0 + 80 * d + 28 * d, ly0 + 6 * d, txt); txt.textAlign = Paint.Align.CENTER
        if (!is3d) {
            val nice = doubleArrayOf(10.0, 20.0, 50.0, 100.0, 200.0, 500.0, 1000.0, 2000.0, 5000.0)
            val len = nice.lastOrNull { it * sc <= w / 3 } ?: 10.0
            cv.drawRect(12 * d, h - 14 * d, 12 * d + (len * sc).toFloat(), h - 12 * d, txt)
            txt.textAlign = Paint.Align.LEFT; cv.drawText(if (len >= 1000) "%.0f km".format(len / 1000) else "%.0f m".format(len), 12 * d, h - 18 * d, txt); txt.textAlign = Paint.Align.CENTER
            cv.drawText("N ↑", w - 22 * d, 18 * d, txt)
        } else {
            txt.textAlign = Paint.Align.LEFT; cv.drawText("drag to rotate · height exaggerated", 10 * d, 16 * d, txt); txt.textAlign = Paint.Align.CENTER
        }
    }
}
