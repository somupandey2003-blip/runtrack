package com.runtrack.app

import android.content.Context
import org.json.JSONObject
import java.util.Calendar

data class RunSum(val id: Long, val date: Long, val dist: Double, val time: Double, val steps: Int, val climb: Double)
object Stats {
    fun sums(ctx: Context): List<RunSum> = Store.ids(ctx).mapNotNull { id ->
        try {
            val r = Store.get(ctx, id) ?: return@mapNotNull null
            RunSum(id, r.getLong("date"), r.getDouble("dist"), r.getDouble("time"), r.getInt("steps"), r.getDouble("elev"))
        } catch (e: Exception) { null }
    }

    private fun zeroed(t: Long): Calendar = Calendar.getInstance().apply {
        timeInMillis = t
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }

    /** Monday 00:00 of the week containing t. */
    fun weekStart(t: Long): Long {
        val c = zeroed(t)
        val offset = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7        // Monday = 0 ... Sunday = 6
        c.add(Calendar.DAY_OF_YEAR, -offset)
        return c.timeInMillis
    }

    fun monthStart(t: Long): Long {
        val c = zeroed(t); c.set(Calendar.DAY_OF_MONTH, 1); return c.timeInMillis
    }

    /** Consecutive days with at least one run, ending today (or yesterday). */
    fun streak(runs: List<RunSum>): Int {
        val tz = java.util.TimeZone.getDefault()
        fun day(t: Long): Long = (t + tz.getOffset(t)) / 86400000L
        val days = runs.map { day(it.date) }.toHashSet()
        var d = day(System.currentTimeMillis())
        if (!days.contains(d)) d -= 1
        var n = 0
        while (days.contains(d)) { n++; d -= 1 }
        return n
    }
}
