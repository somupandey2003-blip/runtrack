package com.runtrack.app

import android.content.Context
import android.location.Location
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject

fun fmt(s: Double): String {
    val t = if (s < 0) 0 else s.toInt()
    val h = t / 3600; val m = t % 3600 / 60; val c = t % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, c) else "%02d:%02d".format(m, c)
}

/** Shared run state, written by TrackingService, read by MainActivity. */
object Tracker {
    data class Pt(val lat: Double, val lon: Double, val t: Long, val acc: Float)
    data class Lap(val n: Int, val d: Double, val t: Double)

    var active = false; var running = false
    val pts = ArrayList<Pt>(); val laps = ArrayList<Lap>()
    var dist = 0.0; var speed = 0.0; var acc = 0f
    var elapsedBase = 0.0; var t0 = 0L
    var lapD0 = 0.0; var lapT0 = 0.0
    var origin: Pt? = null; var away = false; var last: Pt? = null
    var lapMode = 0          // 0 = return to start, 1 = every N metres
    var lapLen = 400.0
    var steps = 0; var rawSteps = -1f; var stepSeen = false
    var onChange: (() -> Unit)? = null

    fun elapsed() = elapsedBase + if (running) (SystemClock.elapsedRealtime() - t0) / 1000.0 else 0.0
    fun stepsShown() = if (stepSeen) steps else (dist / 0.78).toInt()

    fun reset() {
        pts.clear(); laps.clear(); dist = 0.0; speed = 0.0; elapsedBase = 0.0
        lapD0 = 0.0; lapT0 = 0.0; origin = null; away = false; last = null
        steps = 0; rawSteps = -1f; stepSeen = false
        active = true; running = true; t0 = SystemClock.elapsedRealtime()
    }

    fun toggle() {
        if (running) { elapsedBase += (SystemClock.elapsedRealtime() - t0) / 1000.0; running = false }
        else { t0 = SystemClock.elapsedRealtime(); running = true }
        last = null; speed = 0.0
    }

    fun onStep(raw: Float) {
        stepSeen = true
        if (running && rawSteps >= 0) steps += (raw - rawSteps).toInt()
        rawSteps = raw
    }

    fun onFix(l: Location) {
        acc = l.accuracy
        if (!running || l.accuracy > 25f) { onChange?.invoke(); return }   // reject poor fixes
        val p = Pt(l.latitude, l.longitude, l.time, l.accuracy)
        val prev = last
        if (prev != null) {
            val dt = (p.t - prev.t) / 1000.0
            if (dt <= 0) return
            val d = distance(prev, p); val v = d / dt
            if (v > 12) return                                  // outlier jump
            if (d < maxOf(2.0, l.accuracy * 0.4)) {             // jitter inside noise
                speed *= 0.7; onChange?.invoke(); return
            }
            dist += d
            val inst = if (l.hasSpeed()) l.speed.toDouble() else v
            speed = if (speed == 0.0) inst else 0.6 * speed + 0.4 * inst
        }
        last = p; pts.add(p); checkLap(p); onChange?.invoke()
    }

    private fun distance(a: Pt, b: Pt): Double {
        val r = FloatArray(1)
        Location.distanceBetween(a.lat, a.lon, b.lat, b.lon, r); return r[0].toDouble()
    }

    fun addLap(fixed: Double? = null) {
        val t = elapsed()
        laps.add(Lap(laps.size + 1, fixed ?: (dist - lapD0), t - lapT0))
        lapD0 = if (fixed != null) lapD0 + fixed else dist
        lapT0 = t
    }

    private fun checkLap(p: Pt) {
        val o = origin
        if (o == null) { origin = p; return }
        if (lapMode == 1) {
            while (dist - lapD0 >= lapLen) addLap(lapLen)
        } else {
            val dO = distance(o, p)
            if (dO > 40) away = true                           // left start zone
            if (away && dO < 20 && dist - lapD0 > 100) { addLap(); away = false }
        }
    }

    // ---- storage ----
    fun save(ctx: Context) {
        if (dist < 20) return
        if (dist - lapD0 > 30 && laps.isNotEmpty()) laps.add(Lap(laps.size + 1, dist - lapD0, elapsed() - lapT0))
        val o = JSONObject().put("date", System.currentTimeMillis()).put("dist", dist)
            .put("time", elapsed()).put("steps", stepsShown())
        o.put("laps", JSONArray().also { a -> laps.forEach { a.put(JSONObject().put("n", it.n).put("d", it.d).put("t", it.t)) } })
        o.put("pts", JSONArray().also { a -> pts.forEach { a.put(JSONArray().put(it.lat).put(it.lon).put(it.t)) } })
        val sp = ctx.getSharedPreferences("runs", Context.MODE_PRIVATE)
        val all = JSONArray(sp.getString("v", "[]")); val out = JSONArray(); out.put(o)
        for (i in 0 until minOf(all.length(), 49)) out.put(all.get(i))
        sp.edit().putString("v", out.toString()).apply()
    }

    fun load(ctx: Context): JSONArray =
        JSONArray(ctx.getSharedPreferences("runs", Context.MODE_PRIVATE).getString("v", "[]"))

    fun gpx(r: JSONObject): String {
        val sb = StringBuilder("<?xml version=\"1.0\"?><gpx version=\"1.1\" creator=\"RunTrack\"><trk><trkseg>")
        val a = r.getJSONArray("pts")
        val f = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US)
            .apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
        for (i in 0 until a.length()) {
            val p = a.getJSONArray(i)
            sb.append("<trkpt lat=\"${p.getDouble(0)}\" lon=\"${p.getDouble(1)}\"><time>${f.format(java.util.Date(p.getLong(2)))}</time></trkpt>")
        }
        return sb.append("</trkseg></trk></gpx>").toString()
    }
}
