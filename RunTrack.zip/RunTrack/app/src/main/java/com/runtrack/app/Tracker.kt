package com.runtrack.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.*

fun fmt(s: Double): String {
    val t = if (s < 0) 0 else s.toInt()
    val h = t / 3600; val m = t % 3600 / 60; val c = t % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, c) else "%02d:%02d".format(m, c)
}
fun paceStr(kmh: Double) = if (kmh > 0.8) fmt(3600 / kmh) else "--:--"

object M {
    const val STILL = 0; const val WALK = 1; const val RUN = 2; const val CYCLE = 3; const val VEH = 4
    val names = arrayOf("Still", "Walk", "Run", "Cycle", "Vehicle")
}

/** Shared run state. Written by TrackingService, read by the screens. */
object Tracker {
    data class Pt(val lat: Double, val lon: Double, val t: Long, val acc: Float, val alt: Double, val spd: Double, val mode: Int)
    data class Lap(val n: Int, val d: Double, val t: Double)

    var active = false; var running = false
    val pts = ArrayList<Pt>(); val laps = ArrayList<Lap>()
    val mins = ArrayList<Double>(); val minSteps = ArrayList<Int>()
    val modeDist = DoubleArray(5); val modeTime = DoubleArray(5)
    var dist = 0.0; var speed = 0.0; var acc = 0f; var maxSpeed = 0.0; var elevGain = 0.0
    var mode = M.STILL; var manual = 0            // manual: 0 auto, 1 run, 2 walk, 3 cycle, 4 vehicle
    private var candMode = M.STILL; private var candSince = 0L; private var lastFast = -1000000L
    var elapsedBase = 0.0; var t0 = 0L; var runId = 0L
    var lapD0 = 0.0; var lapT0 = 0.0
    var origin: Pt? = null; var away = false; var last: Pt? = null
    var lapMode = 0; var lapLen = 400.0; var loopLen = 0.0; var weight = 70.0
    private var kLat = 0.0; private var kLon = 0.0; private var kVar = -1.0; private var kT = 0L
    private var altS = Double.NaN; private var refAlt = Double.NaN
    var steps = 0; var hwSteps = 0; private var hwRaw = -1f
    var stride = 0.0; private var strideDist = 0.0; private var strideMark = 0
    private var stepsMark = 0; private var lastFixAt = 0L; private var drFlag = false
    private var g = 9.8; private var lp = 0.0; private var p1 = 0.0; private var p2 = 0.0
    private var amp = 2.0; private var lastCand = 0L; private var pending = 0
    private val ints = ArrayDeque<Long>(); private val stepTimes = ArrayDeque<Long>()
    var onChange: (() -> Unit)? = null
    var autoPause = true; var autoPaused = false; private var stillSince = 0L

    fun elapsed() = elapsedBase + if (running) (SystemClock.elapsedRealtime() - t0) / 1000.0 else 0.0
    fun stepsShown() = if (steps > 0) steps else if (hwSteps > 0) hwSteps else (dist / 0.78).toInt()
    private fun manualMode() = when (manual) { 1 -> M.RUN; 2 -> M.WALK; 3 -> M.CYCLE; 4 -> M.VEH; else -> -1 }
    private fun counts(m: Int): Boolean {
        val fm = manualMode()
        return if (fm == M.CYCLE || fm == M.VEH) m == fm else (m == M.WALK || m == M.RUN)
    }
    private fun ensure(i: Int) { while (mins.size <= i) { mins.add(0.0); minSteps.add(0) } }
    private fun addMin(d: Double) { val i = (elapsed() / 60).toInt(); ensure(i); mins[i] = mins[i] + d }

    fun reset() {
        pts.clear(); laps.clear(); mins.clear(); minSteps.clear()
        modeDist.fill(0.0); modeTime.fill(0.0)
        dist = 0.0; speed = 0.0; maxSpeed = 0.0; elevGain = 0.0; mode = M.STILL; candMode = M.STILL
        elapsedBase = 0.0; lapD0 = 0.0; lapT0 = 0.0; origin = null; away = false; last = null
        kVar = -1.0; altS = Double.NaN; refAlt = Double.NaN
        steps = 0; hwSteps = 0; hwRaw = -1f; strideDist = 0.0; strideMark = 0; stepsMark = 0; drFlag = false
        pending = 0; ints.clear(); stepTimes.clear(); lastFast = -1000000L
        runId = System.currentTimeMillis(); autoPaused = false; stillSince = 0L
        active = true; running = true; t0 = SystemClock.elapsedRealtime(); lastFixAt = t0
    }

    fun toggle() {
        if (running) { elapsedBase += (SystemClock.elapsedRealtime() - t0) / 1000.0; running = false }
        else { t0 = SystemClock.elapsedRealtime(); running = true; lastFixAt = t0; autoPaused = false }
        last = null; speed = 0.0; kVar = -1.0
    }

    // ------------------------------------------------------------------ GPS
    fun onFix(l: Location) {
        acc = l.accuracy
        val now = SystemClock.elapsedRealtime()
        if (active && autoPaused && !running) {                                  // auto-resume when moving again
            if (l.accuracy <= 25f && ((l.hasSpeed() && l.speed > 1.2f) || cadence(now) >= 60)) toggle()
            else { onChange?.invoke(); return }
        }
        if (!running || l.accuracy > 25f) { onChange?.invoke(); return }       // reject poor fixes
        // 1. Kalman smoothing of position (variance grows with time, shrinks with each fix)
        val tk = l.elapsedRealtimeNanos / 1000000
        if (kVar < 0) { kLat = l.latitude; kLon = l.longitude; kVar = (l.accuracy * l.accuracy).toDouble() }
        else {
            val q = max(3.0, speed)
            kVar += max(1L, tk - kT) * q * q / 1000.0
            val k = kVar / (kVar + l.accuracy * l.accuracy)
            kLat += k * (l.latitude - kLat); kLon += k * (l.longitude - kLon); kVar *= (1 - k)
        }
        kT = tk
        if (l.hasAltitude()) altS = if (altS.isNaN()) l.altitude else 0.85 * altS + 0.15 * l.altitude
        val prev = last
        val dop = if (l.hasSpeed()) l.speed.toDouble() else -1.0               // Doppler speed (very accurate)
        var d = 0.0; var dt = 0.0
        if (prev != null) {
            dt = (l.time - prev.t) / 1000.0
            if (dt <= 0) return
            d = meters(prev.lat, prev.lon, kLat, kLon)
            val v = d / dt; val s = if (dop >= 0) dop else v
            if (v > 12 && s < 8) return                                        // GPS jump not backed by Doppler
            if (d < max(2.0, l.accuracy * 0.4) && s < 1.2) { speed *= 0.7; classify(now); onChange?.invoke(); return }
            speed = if (speed == 0.0) s else 0.6 * speed + 0.4 * s
            if (drFlag) { d = 0.0; drFlag = false }                            // gap already covered by step dead-reckoning
        }
        classify(now)
        val m = mode
        if (prev != null) {
            modeDist[m] += d; modeTime[m] += min(dt, 10.0)
            if (counts(m)) {
                dist += d; addMin(d); if (speed > maxSpeed) maxSpeed = speed
                if (!altS.isNaN()) {
                    if (refAlt.isNaN()) refAlt = altS
                    else if (altS > refAlt + 2) { elevGain += altS - refAlt; refAlt = altS }
                    else if (altS < refAlt - 2) refAlt = altS
                }
            }
            if ((m == M.WALK || m == M.RUN) && l.accuracy <= 12f) {            // stride calibration from clean GPS
                strideDist += d
                if (strideDist >= 100) {
                    val ds = steps - strideMark
                    if (ds > 40) { val sl = strideDist / ds; if (sl in 0.4..2.2) stride = if (stride == 0.0) sl else 0.7 * stride + 0.3 * sl }
                    strideDist = 0.0; strideMark = steps
                }
            }
        }
        val np = Pt(kLat, kLon, l.time, l.accuracy, if (altS.isNaN()) 0.0 else altS, speed, m)
        last = np; pts.add(np); lastFixAt = now; stepsMark = steps
        checkLap(np); onChange?.invoke()
    }

    /** Called every second: pauses the timer after ~6 s standing still (on foot only). */
    fun autoPauseTick() {
        if (!active) return
        val now = SystemClock.elapsedRealtime()
        val footMode = manual == 0 || manual == 1 || manual == 2
        if (running && autoPause && footMode && (mode == M.STILL || mode == M.WALK || mode == M.RUN)) {
            if (speed < 0.6 && cadence(now) < 30) {
                if (stillSince == 0L) stillSince = now
                else if (now - stillSince >= 6000) { stillSince = 0L; toggle(); autoPaused = true }
            } else stillSince = 0L
        } else stillSince = 0L
    }

    /** Called every second: when GPS is lost for >15 s on foot, extend the distance from steps x calibrated stride. */
    fun deadReckon() {
        val now = SystemClock.elapsedRealtime()
        if (running && stride > 0 && (mode == M.WALK || mode == M.RUN) && now - lastFixAt > 15000) {
            val ds = steps - stepsMark
            if (ds > 0) { val d = ds * stride; dist += d; modeDist[mode] += d; addMin(d); drFlag = true }
            stepsMark = steps
        }
    }

    /** Activity detection from GPS speed + step cadence, with a 6 s debounce. */
    private fun classify(now: Long) {
        val fm = manualMode()
        if (fm >= 0) { mode = fm; return }
        val cad = cadence(now); val stepping = cad >= 50
        if (speed > 9) lastFast = now
        val c = when {
            speed < 0.5 -> M.STILL
            speed > 9 -> M.VEH                                   // >32 km/h: not human powered
            stepping -> when {
                cad >= 125 && speed <= 7.5 -> M.RUN
                speed >= 2.6 -> M.CYCLE                         // slow "cadence" at speed = pedalling
                speed >= 2.2 -> M.RUN
                else -> M.WALK
            }
            now - lastFast < 120000 -> M.VEH                     // crawling in traffic after fast travel
            speed >= 2.0 -> M.CYCLE
            else -> if (mode == M.CYCLE || mode == M.VEH) mode else M.WALK
        }
        if (c == mode) { candMode = c; candSince = now }
        else { if (c != candMode) { candMode = c; candSince = now }; if (now - candSince >= 6000) mode = c }
    }

    private fun meters(a: Double, b: Double, c: Double, d: Double): Double {
        val r = FloatArray(1); Location.distanceBetween(a, b, c, d, r); return r[0].toDouble()
    }

    // ---------------------------------------------------------------- steps
    /** Accelerometer pedometer: smoothed magnitude, adaptive peak threshold, rhythm validation. */
    fun onAccel(x: Float, y: Float, z: Float, now: Long) {
        val m = sqrt((x * x + y * y + z * z).toDouble())
        g = 0.99 * g + 0.01 * m
        lp = 0.6 * lp + 0.4 * (m - g)
        if (active && p1 > p2 && p1 >= lp && p1 > max(1.0, 0.5 * amp) && now - lastCand > 250) candidate(now, p1)
        p2 = p1; p1 = lp
    }

    private fun candidate(now: Long, a: Double) {
        val dt = now - lastCand; lastCand = now
        if (dt > 1500) { pending = 1; ints.clear(); return }
        ints.addLast(dt); if (ints.size > 8) ints.removeFirst()
        val med = ints.sorted()[ints.size / 2]
        if (ints.size >= 3 && (dt < med / 2 || dt > med * 2)) { pending = 0; ints.clear(); return }   // irregular = not stepping
        amp = 0.9 * amp + 0.1 * a
        pending++
        if (pending == 4) addSteps(4, now) else if (pending > 4) addSteps(1, now)   // count only after 4 rhythmic steps
    }

    private fun addSteps(n: Int, now: Long) {
        repeat(n) { stepTimes.addLast(now) }
        if (running && (mode == M.STILL || mode == M.WALK || mode == M.RUN)) {
            steps += n
            val i = (elapsed() / 60).toInt(); ensure(i); minSteps[i] = minSteps[i] + n
        }
    }

    fun cadence(now: Long = SystemClock.elapsedRealtime()): Int {
        while (stepTimes.isNotEmpty() && now - stepTimes.first() > 10000) stepTimes.removeFirst()
        return stepTimes.size * 6
    }

    fun onHw(raw: Float) { if (hwRaw >= 0 && running) hwSteps += (raw - hwRaw).toInt(); hwRaw = raw }

    // ----------------------------------------------------------------- laps
    fun addLap(fixed: Double? = null) {
        val t = elapsed()
        val ld = fixed ?: (dist - lapD0)
        if (lapMode == 2 && loopLen <= 0 && fixed == null && ld >= 50) loopLen = ld   // first lap sets the loop length
        laps.add(Lap(laps.size + 1, ld, t - lapT0))
        lapD0 = if (fixed != null) lapD0 + fixed else dist
        lapT0 = t
    }

    private fun checkLap(p: Pt) {
        val o = origin
        if (o == null) { origin = p; return }
        if (lapMode == 1) { while (dist - lapD0 >= lapLen) addLap(lapLen) }
        else if (lapMode == 2 && loopLen > 0) { while (dist - lapD0 >= loopLen) addLap(loopLen) }   // learned loop: exact same distance every lap
        else {
            val dO = meters(o.lat, o.lon, p.lat, p.lon)
            if (dO > 40) away = true
            if (away && dO < 20 && dist - lapD0 > 100) { addLap(); away = false }
        }
    }

    // ------------------------------------------------------------- lifecycle
    fun finishRun(ctx: Context): Long? {
        loopLen = 0.0
        if (!active) return null
        if (running) toggle()
        active = false; running = false
        return saveRun(ctx)
    }

    /** Saves the current run to Memories and starts a fresh one immediately (tracking continues). */
    fun resetRun(ctx: Context): Boolean {
        val wasPaused = !running && !autoPaused
        if (running) toggle()
        val saved = saveRun(ctx) != null
        reset()
        if (wasPaused) toggle()
        return saved
    }

    private fun saveRun(ctx: Context): Long? {
        Store.ckpt(ctx).delete()
        if (dist < 20) return null
        if (lapMode == 0 && laps.isNotEmpty() && dist - lapD0 > 30) laps.add(Lap(laps.size + 1, dist - lapD0, elapsed() - lapT0))
        Store.put(ctx, toJson())
        return runId
    }

    fun checkpoint(ctx: Context) { if (active && dist > 5) try { Store.ckpt(ctx).writeText(toJson().toString()) } catch (e: Exception) {} }

    fun recover(ctx: Context) {
        val f = Store.ckpt(ctx)
        if (!active && f.exists()) {
            try { val o = JSONObject(f.readText()); if (o.getDouble("dist") >= 20) Store.put(ctx, o) } catch (e: Exception) {}
            f.delete()
        }
    }

    fun toJson(): JSONObject {
        val o = JSONObject().put("id", runId).put("date", runId).put("dist", dist).put("time", elapsed())
            .put("steps", stepsShown()).put("maxSpeed", maxSpeed).put("elev", elevGain)
            .put("stride", stride).put("weight", weight).put("note", "")
        o.put("modeDist", JSONArray(modeDist.toList())).put("modeTime", JSONArray(modeTime.toList()))
        o.put("mins", JSONArray(ArrayList(mins))).put("minSteps", JSONArray(ArrayList(minSteps)))
        o.put("photos", JSONArray())
        o.put("laps", JSONArray().also { a -> laps.forEach { a.put(JSONObject().put("n", it.n).put("d", it.d).put("t", it.t)) } })
        o.put("pts", JSONArray().also { a ->
            pts.forEach { a.put(JSONArray().put(it.lat).put(it.lon).put(it.t).put(it.alt).put(it.spd).put(it.mode)) }
        })
        return o
    }

    fun ptsFromJson(a: JSONArray): List<Pt> = List(a.length()) {
        val p = a.getJSONArray(it)
        Pt(p.getDouble(0), p.getDouble(1), p.getLong(2), 0f, p.getDouble(3), p.getDouble(4), p.getInt(5))
    }

    fun gpx(r: JSONObject): String {
        val sb = StringBuilder("<?xml version=\"1.0\"?><gpx version=\"1.1\" creator=\"RunTrack\"><trk><trkseg>")
        val a = r.getJSONArray("pts")
        val f = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US)
            .apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
        for (i in 0 until a.length()) {
            val p = a.getJSONArray(i)
            sb.append("<trkpt lat=\"${p.getDouble(0)}\" lon=\"${p.getDouble(1)}\"><ele>${p.getDouble(3)}</ele><time>${f.format(java.util.Date(p.getLong(2)))}</time></trkpt>")
        }
        return sb.append("</trkseg></trk></gpx>").toString()
    }
}

/** One JSON file per run in app storage (no size limit), plus a crash-recovery checkpoint. */
object Store {
    private fun dir(c: Context) = File(c.filesDir, "runs").apply { mkdirs() }
    fun put(c: Context, o: JSONObject) { File(dir(c), o.getLong("id").toString() + ".json").writeText(o.toString()) }
    fun get(c: Context, id: Long): JSONObject? = File(dir(c), "$id.json").takeIf { it.exists() }?.let { JSONObject(it.readText()) }
    fun ids(c: Context): List<Long> = (dir(c).listFiles() ?: emptyArray()).mapNotNull { it.nameWithoutExtension.toLongOrNull() }.sortedDescending()
    fun del(c: Context, id: Long) { File(dir(c), "$id.json").delete() }
    fun ckpt(c: Context) = File(c.filesDir, "ckpt.json")
}

fun thumb(path: String, px: Int): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, o)
    var s = 1; while (o.outWidth / s > px * 2) s *= 2
    return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
}
