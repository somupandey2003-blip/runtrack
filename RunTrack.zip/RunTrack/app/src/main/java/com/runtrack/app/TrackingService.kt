package com.runtrack.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.*
import com.google.android.gms.location.*

class TrackingService : Service(), SensorEventListener {
    private lateinit var fused: FusedLocationProviderClient
    private lateinit var sm: SensorManager
    private var wl: PowerManager.WakeLock? = null
    private val h = Handler(Looper.getMainLooper())
    private var ticks = 0
    private val cb = object : LocationCallback() {
        override fun onLocationResult(r: LocationResult) { r.locations.forEach { Tracker.onFix(it) } }
    }
    private val tick = object : Runnable {
        override fun run() {
            Tracker.autoPauseTick()
            Tracker.deadReckon()
            if (++ticks % 30 == 0) Tracker.checkpoint(this@TrackingService)   // crash/kill protection
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, notif())
            h.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        fused = LocationServices.getFusedLocationProviderClient(this)
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val ch = NotificationChannel("run", "Run tracking", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null) { stopSelf(); return START_NOT_STICKY }
        when (i.action) {
            "START" -> if (!Tracker.active) begin()
            "PAUSE" -> Tracker.toggle()
            "LAP" -> if (Tracker.running) Tracker.addLap()
            "STOP" -> finish()
        }
        Tracker.onChange?.invoke()
        return START_STICKY
    }

    private fun begin() {
        Tracker.reset()
        val n = notif()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        else startForeground(1, n)
        wl = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "runtrack:gps").apply { acquire(8 * 60 * 60 * 1000L) }
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
            .setMinUpdateIntervalMillis(500L).setMinUpdateDistanceMeters(0f)
            .setWaitForAccurateLocation(false).build()
        try { fused.requestLocationUpdates(req, cb, Looper.getMainLooper()) } catch (e: SecurityException) { finish() }
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        h.post(tick)
    }

    private fun finish() {
        if (Tracker.active) Tracker.finishRun(this)
        fused.removeLocationUpdates(cb); sm.unregisterListener(this); h.removeCallbacks(tick)
        wl?.let { if (it.isHeld) it.release() }
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    private fun notif(): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, "run")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("%.2f km  ·  %s".format(Tracker.dist / 1000, fmt(Tracker.elapsed())))
            .setContentText(M.names[Tracker.mode] + "  ·  loops " + Tracker.laps.size + (if (Tracker.running) "" else if (Tracker.autoPaused) "  (auto-paused)" else "  (paused)"))
            .setContentIntent(pi).setOngoing(true).build()
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type == Sensor.TYPE_ACCELEROMETER)
            Tracker.onAccel(e.values[0], e.values[1], e.values[2], SystemClock.elapsedRealtime())
        else Tracker.onHw(e.values[0])
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}
