package com.runtrack.app

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.*

const val BG = 0xFF0E1013.toInt()
const val CARD = 0xFF1A1D21.toInt()
const val MUTED = 0xFF9AA1AB.toInt()
const val ACC = 0xFFFC4C02.toInt()
const val WHITE = 0xFFFFFFFF.toInt()
const val GREEN = 0xFF22C55E.toInt()
const val RED = 0xFFEF4444.toInt()
const val BLUE = 0xFF3B82F6.toInt()

fun Context.dp(i: Int) = (i * resources.displayMetrics.density).toInt()

fun Context.tv(t: String, size: Float = 14f, color: Int = WHITE, bold: Boolean = false) =
    TextView(this).apply { text = t; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }

/** A text cell with a layout weight, for table-like rows. */
fun Context.cell(t: String, weight: Float = 1f, color: Int = WHITE, bold: Boolean = false, size: Float = 13f) =
    tv(t, size, color, bold).apply { layoutParams = LinearLayout.LayoutParams(0, -2, weight); setPadding(0, dp(3), 0, dp(3)) }

private fun Context.styled(t: String, bg: Int, f: () -> Unit) = Button(this).apply {
    text = t; isAllCaps = false; setTextColor(WHITE); typeface = Typeface.DEFAULT_BOLD; textSize = 15f
    background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(12).toFloat() }
    setOnClickListener { f() }
    layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
}

fun Context.btn(t: String, f: () -> Unit) = styled(t, 0xFF2F343B.toInt(), f)
fun Context.pbtn(t: String, f: () -> Unit) = styled(t, ACC, f)
fun Button.enable(on: Boolean) { isEnabled = on; alpha = if (on) 1f else 0.4f }

fun Context.row(vararg v: View) = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL; v.forEach { addView(it) }
}

fun Context.card(vararg v: View) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(12), dp(10), dp(12), dp(10))
    background = GradientDrawable().apply { setColor(CARD); cornerRadius = dp(14).toFloat() }
    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
    v.forEach { addView(it) }
}

class Stat(c: Context, label: String, size: Float = 26f) {
    val v = c.tv("0", size, WHITE, true)
    val view = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(c.dp(6), c.dp(6), c.dp(6), c.dp(6))
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        addView(v); addView(c.tv(label.uppercase(), 10f, MUTED))
    }
}

fun Context.statGrid(items: List<Pair<String, String>>, cols: Int = 3): LinearLayout {
    val g = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    for (chunk in items.chunked(cols)) {
        val r = row()
        for (p in chunk) { val s = Stat(this, p.first, 20f); s.v.text = p.second; r.addView(s.view) }
        repeat(cols - chunk.size) { r.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) }) }
        g.addView(r)
    }
    return g
}
